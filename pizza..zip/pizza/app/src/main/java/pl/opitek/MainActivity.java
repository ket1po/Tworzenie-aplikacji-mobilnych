package pl.opitek;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.List;

public class MainActivity extends AppCompatActivity {
private TextView wynik;
private Spinner lista;
private TextView wybor;
private String wybrane;
private pizzaRodzaje porada = new pizzaRodzaje();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        wynik = findViewById(R.id.tv1);
        lista = findViewById(R.id.sp1);
        wybor = findViewById(R.id.b1);
    }

    public void Start_Click(View view) {
        //TextView wynik = findViewById(R.id.tv1);
        //Spinner lista = findViewById(R.id.sp1);
        wybrane = lista.getSelectedItem().toString();
        List<String> ListaPizzy = porada.getRodzaje(wybrane);
        StringBuilder pizzeSformatowane = new StringBuilder();
        for (String wyni : ListaPizzy) {
            pizzeSformatowane.append(wyni).append("\n");
        }
        wynik.setText(pizzeSformatowane);
    }
}