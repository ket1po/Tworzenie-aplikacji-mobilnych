package pl.opitek;

import java.util.ArrayList;
import java.util.List;

public class pizzaRodzaje {
    List<String> getRodzaje(String dodatki) {
        List<String> rodzaje = new ArrayList<String>();
        if (dodatki.equals("pieczarki")){
            rodzaje.add("Capriciosa");
            rodzaje.add("Jakś z pieczarkami");
        }
        else  {
            rodzaje.add("Salami");
            rodzaje.add("Margharita");
        }
        return rodzaje;
    }



}
