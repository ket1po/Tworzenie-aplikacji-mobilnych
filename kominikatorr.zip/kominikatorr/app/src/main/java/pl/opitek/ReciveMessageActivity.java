package pl.opitek;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class ReciveMessageActivity extends AppCompatActivity {
    public static final String EXTRA_MESSAGE = "message";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recive_message);
        Intent intent = getIntent();
        String strWiadmosc = intent.getStringExtra(EXTRA_MESSAGE);
        TextView vieWiadmosc = (TextView)findViewById(R.id.txtWynik);
        vieWiadmosc.setText(strWiadmosc);
    }





    public void b1(View view) {
        EditText wiadomosc = findViewById(R.id.txtWynik);
        String strWiadmosoc = wiadomosc.getText().toString();
        Intent intent = new Intent(this, ReciveMessageActivity.class);
        intent.putExtra(ReciveMessageActivity.EXTRA_MESSAGE, strWiadmosoc);
        startActivity(intent);
    }

}